package com.example.auth_service.interfaces.rest;

import com.example.auth_service.application.auth.PasswordLoginHandler;
import com.example.auth_service.application.auth.RefreshTokenHandler;
import com.example.auth_service.interfaces.rest.dto.auth.PasswordLoginRequest;
import com.example.auth_service.interfaces.rest.dto.auth.TokenResponse;
import com.example.auth_service.interfaces.rest.dto.auth.RefreshRequest;
import com.example.auth_service.interfaces.rest.dto.auth.LogoutRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/auth")
@Tag(name = "Autenticação", description = "Endpoints para autenticação, refresh token e logout no e-commerce RV Pneus")
public class AuthController {
    private final PasswordLoginHandler passwordLoginHandler;
    private final RefreshTokenHandler refreshTokenHandler;

    @PostMapping("/login")
    @Operation(summary = "Login com email e senha", 
               description = "Realiza autenticação do usuário e retorna token de acesso e refresh token")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Login realizado com sucesso",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = TokenResponse.class))),
        @ApiResponse(responseCode = "401", description = "Credenciais inválidas"),
        @ApiResponse(responseCode = "400", description = "Dados de entrada inválidos")
    })
    public ResponseEntity<TokenResponse> loginWithPassword(@Valid @RequestBody PasswordLoginRequest request) {
        TokenResponse token = passwordLoginHandler.handle(request.email(), request.password());
        return ResponseEntity.ok(token);
    }

    @PostMapping("/refresh")
    @Operation(summary = "Renovar token de acesso", 
               description = "Utiliza o refresh token para obter um novo token de acesso e um novo refresh token")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Token renovado com sucesso",
                    content = @Content(mediaType = "application/json", 
                                     schema = @Schema(implementation = TokenResponse.class))),
        @ApiResponse(responseCode = "401", description = "Refresh token inválido ou expirado"),
        @ApiResponse(responseCode = "400", description = "Refresh token não fornecido")
    })
    public ResponseEntity<TokenResponse> refresh(@Valid @RequestBody RefreshRequest request) {
        var pair = refreshTokenHandler.refresh(request.refreshToken());
        return ResponseEntity.ok(new TokenResponse(pair.token(), pair.refreshToken(), pair.expiresIn()));
    }

    @PostMapping("/logout")
    @Operation(summary = "Logout do usuário", 
               description = "Invalida o refresh token, impedindo sua reutilização")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Logout realizado com sucesso"),
        @ApiResponse(responseCode = "400", description = "Refresh token não fornecido")
    })
    public ResponseEntity<Void> logout(@Valid @RequestBody LogoutRequest request) {
        refreshTokenHandler.logout(request.refreshToken());
        return ResponseEntity.noContent().build();
    }
}

